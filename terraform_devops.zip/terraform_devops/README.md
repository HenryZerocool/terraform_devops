# Simple Devops Project

1. Maven Project
   Jenkins will pull this Maven projects, go through all pipeline and in the end deploy to Tomcat

2. Terraform
   Provision 4 AWS server: Jenkins, Nexus, Ansible and Tomcat
